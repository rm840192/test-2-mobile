﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Test_Rahul
{
    [Activity(Label = "Register")]
    public class Register : Activity
    {
        EditText firstName;
        EditText lastName;
        EditText studentID;
        AlertDialog alert;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // Create your application here

            SetContentView(Resource.Layout.register);

            firstName = FindViewById<EditText>(Resource.Id.firstName);
            lastName = FindViewById<EditText>(Resource.Id.lastName);
            studentID = FindViewById<EditText>(Resource.Id.studentId);
            Button save = FindViewById<Button>(Resource.Id.buttonSave);
            Button back = FindViewById<Button>(Resource.Id.buttonBack);

            save.Click += delegate
            {
                if (!string.IsNullOrEmpty(firstName.Text) && !string.IsNullOrEmpty(lastName.Text) && !string.IsNullOrEmpty(studentID.Text))
                {
                    if (!Student.Ids.Contains(studentID.Text))
                    {
                        alert = (new AlertDialog.Builder(this)).Create();
                        alert.SetMessage("Are you sure you want to register this student to calculate the GPA?");
                        alert.SetButton("Yes, I'm Sure!", ButtonOk);
                        alert.SetButton2("No Way!", ButtonNok);
                        alert.Show();
                    }
                    else
                    {
                        Toast.MakeText(this, "Error!\nThis student number has already been added", ToastLength.Short).Show();
                    }

                }
                else
                {
                    Toast.MakeText(this, "Error!\nPlease check if all the fields are filled before calculating ", ToastLength.Short).Show();
                }
            };


            back.Click += delegate
            {
                Finish();
            };

        }

        private void ButtonNok(object sender, EventArgs e)
        {
            alert.Dismiss();
        }

        private void ButtonOk(object sender, EventArgs e)
        {
            var name = firstName.Text + " " + lastName.Text;
            Student student = new Student(name, studentID.Text);
            Student.Students.Add(student);
            Student.Ids.Add(studentID.Text);

            Toast.MakeText(this, $"{firstName.Text} is now a student", ToastLength.Short).Show();

            firstName.Text = null;
            lastName.Text = null;
            studentID.Text = null;
        }
    }
}
