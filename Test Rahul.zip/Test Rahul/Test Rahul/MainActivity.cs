﻿using Android.App;
using Android.OS;
using Android.Support.V7.App;
using System.Collections.Generic;
using Android.Runtime;
using Android.Widget;
using Android.Content;

namespace Test_Rahul
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        SearchView studentsSearch;
        ListView myList;
        Button addNew;
        ArrayAdapter adapter;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            // Set our view from the "main" layout resource
            SetContentView(Resource.Layout.activity_main);

        
        studentsSearch = FindViewById<SearchView>(Resource.Id.searchView1);
            myList = FindViewById<ListView>(Resource.Id.listView1);
            addNew = FindViewById<Button>(Resource.Id.button1);

            studentsSearch.QueryTextChange += (s, e) =>
            {
                adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, Student.Students);
        myList.Adapter = adapter;
                adapter.Filter.InvokeFilter(e.NewText);
            };

    myList.ItemClick += (s, e) =>
            {
                string name_selected = adapter.GetItem(e.Position).ToString();

    name_selected = name_selected.Substring(name_selected.IndexOf("\n") + 5);
                name_selected = name_selected.Substring(0, name_selected.IndexOf("\n"));
                int position = Student.Ids.IndexOf(name_selected);

    Intent intent = new Intent(this, typeof(CreateGpa));
    intent.PutExtra("Position", position);
                StartActivity(intent);
};


addNew.Click += delegate
            {
                Intent intent = new Intent(this, typeof(Register));
StartActivity(intent);
            };

        }

        protected override void OnRestart()
{
    base.OnRestart();
    studentsSearch.SetQuery("", false);
    adapter = new ArrayAdapter(this, Android.Resource.Layout.SimpleListItem1, Student.Students);
    myList.Adapter = adapter;
}
    }
}
