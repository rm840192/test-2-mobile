﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Test_Rahul
{
    [Activity(Label = "CreateGpa")]
    public class CreateGpa : Activity
    {
        string studentName;
        string studentId;
        double studentGpa;
        double grade1;
        double grade2;
        double grade3;
        double grade4;
        double grade5;
        int position;
        AlertDialog alert;
        EditText txtGrade1;
        EditText txtGrade2;
        EditText txtGrade3;
        EditText txtGrade4;
        EditText txtGrade5;
        TextView idCourse1;
        TextView idCourse2;
        TextView idCourse3;
        TextView idCourse4;
        TextView idCourse5;
       


        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resource.Layout.gpa);

            TextView txtStudentName = FindViewById<TextView>(Resource.Id.txtStudentName);
            TextView txtStudentID = FindViewById<TextView>(Resource.Id.txtStudentId);
            idCourse1 = FindViewById<TextView>(Resource.Id.idCourse1);
            txtGrade1 = FindViewById<EditText>(Resource.Id.txtGrade1);
            idCourse2 = FindViewById<TextView>(Resource.Id.idCourse2);
            txtGrade2 = FindViewById<EditText>(Resource.Id.txtGrade2);
            idCourse3 = FindViewById<TextView>(Resource.Id.idCourse3);
            txtGrade3 = FindViewById<EditText>(Resource.Id.txtGrade3);
            idCourse4 = FindViewById<TextView>(Resource.Id.idCourse4);
            txtGrade4 = FindViewById<EditText>(Resource.Id.txtGrade4);
            idCourse5 = FindViewById<TextView>(Resource.Id.idCourse5);
            txtGrade5 = FindViewById<EditText>(Resource.Id.txtGrade5);
            TextView txtGPA = FindViewById<TextView>(Resource.Id.txtGPA);
            Button save = FindViewById<Button>(Resource.Id.saveButton);

            position = Intent.GetIntExtra("Position", -1);
            studentName = Student.Students[position].Name;
            studentId = Student.Students[position].Id;
            studentGpa = Student.Students[position].Gpa;

            txtStudentName.Text = "Student Name: " + studentName;
            txtStudentID.Text = "Student ID: " + studentId;
            txtGPA.Text = "GPA: " + studentGpa.ToString();
            txtGrade1.Hint = Student.Students[position].Grade1.ToString();
            txtGrade2.Hint = Student.Students[position].Grade2.ToString();
            txtGrade3.Hint = Student.Students[position].Grade3.ToString();
            txtGrade4.Hint = Student.Students[position].Grade4.ToString();
            txtGrade5.Hint = Student.Students[position].Grade5.ToString();


            save.Click += delegate
            {
                if (!string.IsNullOrEmpty(txtGrade1.Text) && !string.IsNullOrEmpty(txtGrade2.Text) && !string.IsNullOrEmpty(txtGrade3.Text)
                && !string.IsNullOrEmpty(txtGrade4.Text) && !string.IsNullOrEmpty(txtGrade5.Text))
                {
                    grade1 = Convert.ToDouble(txtGrade1.Text);
                    grade2 = Convert.ToDouble(txtGrade2.Text);
                    grade3 = Convert.ToDouble(txtGrade3.Text);
                    grade4 = Convert.ToDouble(txtGrade4.Text);
                    grade5 = Convert.ToDouble(txtGrade5.Text);

                    if (grade1 < 0 || grade1 > 100 || grade2 < 0 || grade2 > 100 || grade3 < 0 || grade3 > 100 ||
                    grade4 < 0 || grade4 > 100 || grade5 < 0 || grade5 > 100)
                    {
                        Toast.MakeText(this, "Error!\nThe grades have to be between 0 and 100", ToastLength.Long).Show();
                    }
                    else
                    {
                        alert = (new AlertDialog.Builder(this)).Create();
                        alert.SetMessage("Are you sure you want to save these Grades?");
                        alert.SetButton("Yes, I'm Sure!", YesButtonClick);
                        alert.SetButton2("No Way!", NoButtonClick);
                        alert.Show();
                    }
                }
                else
                {
                    Toast.MakeText(this, "Error!\nPlease fill all the fields", ToastLength.Long).Show();
                }

            };

        }

        private void NoButtonClick(object sender, EventArgs e)
        {
            alert.Dismiss();
        }

        private void YesButtonClick(object sender, EventArgs e)
        {
            studentGpa = CalculateGPA();

            Student student = new Student(studentName, studentId, studentGpa, grade1, grade2, grade3, grade4, grade5);
            Student.Students[position] = student;

            if (studentGpa > 2.8)
            {
                Toast.MakeText(this, $"Student {studentName} is qualified to take a co-op", ToastLength.Long).Show();
            }
            else
            {
                Toast.MakeText(this, $"Student {studentName} is not qualified to take a co-op", ToastLength.Long).Show();
            }

            Finish();
        }

        private double CalculateGPA()
        {
            double gradePointCourse1 = getGradePoint(grade1);
            double gradePointCourse2 = getGradePoint(grade2);
            double gradePointCourse3 = getGradePoint(grade3);
            double gradePointCourse4 = getGradePoint(grade4);
            double gradePointCourse5 = getGradePoint(grade5);

            double credits1 = Convert.ToDouble(idCourse1.Text.Substring(idCourse1.Text.Length - 1, 1));
            double credits2 = Convert.ToDouble(idCourse2.Text.Substring(idCourse2.Text.Length - 1, 1));
            double credits3 = Convert.ToDouble(idCourse3.Text.Substring(idCourse3.Text.Length - 1, 1));
            double credits4 = Convert.ToDouble(idCourse4.Text.Substring(idCourse4.Text.Length - 1, 1));
            double credits5 = Convert.ToDouble(idCourse5.Text.Substring(idCourse5.Text.Length - 1, 1));

            double gpa = (gradePointCourse1 * credits1 + gradePointCourse2 * credits2 + gradePointCourse3 * credits3 +
                gradePointCourse4 * credits4 + gradePointCourse5 * credits5) / (credits1 + credits2 + credits3 + credits4 + credits5);

            return gpa;
        }


        public double getGradePoint(double gradeMark)
        {
            double gradePoint = 0;

            if (gradeMark <= 100 && gradeMark >= 94)
                gradePoint = 4.0;
            else if (gradeMark <= 93 && gradeMark >= 87)
                gradePoint = 3.7;
            else if (gradeMark <= 86 && gradeMark >= 80)
                gradePoint = 3.5;
            else if (gradeMark <= 79 && gradeMark >= 77)
                gradePoint = 3.2;
            else if (gradeMark <= 76 && gradeMark >= 73)
                gradePoint = 3.0;
            else if (gradeMark <= 72 && gradeMark >= 70)
                gradePoint = 2.7;
            else if (gradeMark <= 69 && gradeMark >= 67)
                gradePoint = 2.3;
            else if (gradeMark <= 66 && gradeMark >= 63)
                gradePoint = 2.0;
            else if (gradeMark <= 62 && gradeMark >= 60)
                gradePoint = 1.7;
            else if (gradeMark <= 59 && gradeMark >= 50)
                gradePoint = 1.0;
            else if (gradeMark <= 49 && gradeMark >= 0)
                gradePoint = 0.0;

            return gradePoint;
        }
    }
}


            // Create your application here
        